# Free-SS-SSR

谢谢大家一直以来的支持:blush:，为了方便统一维护，本项目已迁移到：[www.youneed.win](https://www.youneed.win)

历史提交中的很多账号仍然能够使用，大家也可以继续查找使用。

如有任何问题，欢迎在issues中交流。

### :palm_tree: [SS账号](https://www.youneed.win/free-ss)

### :deciduous_tree: [SSR账号](https://www.youneed.win/free-ssr)

所有账号均来自互联网，非盈利目的，仅供大家交流学习使用，请勿用于非法用途:sos:。

服务器有点垃圾，偶尔不能访问时，可以提issue或发邮件:email:。

------
**2019.07.25更新**

很不幸，原来的域名被和谐，因此启用了临时域名[flywind.ml](https://flywind.ml)，希望大家低调使用。

主域名[www.youneed.win](https://www.youneed.win)不会变更，大家可以书签收藏。临时域名和谐后会及时更新。

### :palm_tree: [SS账号](https://flywind.ml//free-ss)

### :deciduous_tree: [SSR账号](https://flywind.ml//free-ssr)

[若本项目对您有所帮助，欢迎Star](https://github.com/dxxzst/Free-SS-SSR)
