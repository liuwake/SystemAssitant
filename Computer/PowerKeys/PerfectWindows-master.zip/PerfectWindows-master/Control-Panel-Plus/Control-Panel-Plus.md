# Windows 高级控制面板

![demo](https://github.com/szzhiyang/Pics/raw/master/PerfectWindows/cpp1.jpg)

---

**[32 位版本](https://github.com/szzhiyang/PerfectWindows/raw/master/Control-Panel-Plus/Control-Panel-Plus-x86.exe)  （无法在 64 位 Windows 上运行）**

**[64 位版本](https://github.com/szzhiyang/PerfectWindows/raw/master/Control-Panel-Plus/Control-Panel-Plus-x64.exe)  （无法在 32 位 Windows 上运行）**

---

**Windows 高级控制面板为免安装型软件。**

**Windows 高级控制面板** 是由 Ahk2Exe 生成的，您可以在 repository 中找到它的源文件。

---

### 如果 Windows 高级控制面板解决了您的心头之患，不妨请我喝杯咖啡 :coffee:，想必也是非常愉悦的事情！:pray::heart:

![支付](https://github.com/szzhiyang/Pics/raw/master/PerfectWindows/Pay.jpg)

