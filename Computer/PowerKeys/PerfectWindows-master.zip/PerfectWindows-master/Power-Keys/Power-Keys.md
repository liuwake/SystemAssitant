<br>

# Power Keys

<br>

**键盘流效率软件中的瑞士军刀！**

<br>

## 功能大全

<br>

**启动器**

>**借助全局快捷键启动应用、访问网站、打开文件、执行命令或者修改 Windows 设置。**

<br>

**空格编辑**

>**码字从未如此流畅！**

<br>

**数字小键盘**

>**在任何笔记本电脑上使用可以盲打的数字小键盘！**

<br>

**增强的 Windows 快捷键**

>**切歌、调整音量、清空回收站、启动 Windows 计算器和截图工具、休眠 Windows……**

<br>

**游戏模式**

>**在打游戏时轻松自如地切歌、调整音量，并屏蔽 Windows 徽标键。**

<br>

**简化快捷键**

>**不费吹灰之力地按下复杂的快捷键。**

<br>

**多任务处理**

>**多任务处理从未如此高效！**

<br>

**扩展截图快捷键和录屏快捷键**

>**再也不用担心截图软件和录屏软件的全局快捷键不够用了！**

<br>

## 媒体报道

<br>

[**Power Keys - 让键盘党爽爆的免费开源一键启动软件利器 (全局快捷键工具)**](https://www.iplaysoft.com/power-keys.html) 
> **异次元软件世界文章**

<br>

[**如何彻底提升码字效率？**](https://zhuanlan.zhihu.com/p/37346660)
> **作者知乎文章**

<br>

## 下载与帮助

<br>

[**32 位**](https://github.com/szzhiyang/PerfectWindows/raw/master/Power-Keys/Power-Keys-x86.exe)   [**64 位**](https://github.com/szzhiyang/PerfectWindows/raw/master/Power-Keys/Power-Keys-x64.exe) [**帮助文档**](https://github.com/szzhiyang/PerfectWindows/wiki/Power-Keys)

<br>

## 支持作者

<br>

**如果 Power Keys 提升了您的 Windows 使用效率，不妨请我喝杯咖啡 :coffee:，想必也是非常愉悦的事情！** :pray::heart:

![支付](https://github.com/szzhiyang/Pics/raw/master/PerfectWindows/Pay.jpg)
